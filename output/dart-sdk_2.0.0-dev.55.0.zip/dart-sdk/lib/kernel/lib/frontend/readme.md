Utility method to help the frontend generate kernel IR.
