Conversion to and from a binary format.

The binary format is described in [binary.md](../../binary.md).
