A frontend using the Dart analyzer.
