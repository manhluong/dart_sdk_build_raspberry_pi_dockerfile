// Copyright (c) 2014, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

/// Please see 'dart:developer'.
@Deprecated("Dart SDK 1.12")
library dart.profiler;

export 'dart:developer'
    show getCurrentTag, Counter, Gauge, Metric, Metrics, UserTag;
